# Visual preservation checklist
Identity is fixed; this is NOT a redesign brief.

Preserve the white custom YCN letterforms, the split at the Y junction, the opening through the C, the curved diagonal treatment of the N, the spacing and blue/cyan treatment of LABS, the luminous left crescent, upper and lower orbital lines, ringed and solid nodes, faint connecting network lines, and the long underline with its bright right-hand flare.

Do not substitute a font for the lettering. Do not invent missing connections. Do not thicken faint lines to make a small export appear stronger. Do not erase the glow, reduce node count, simplify the crescent, remove the background, recolour, stretch or rearrange elements without a separately reviewed and explicitly approved variant.

At small dimensions, resampling necessarily combines pixels. Preserving the source design does not mean every fine feature remains separately visible at every size. Solve that with a separately approved compact identity asset, not a silent redesign.
