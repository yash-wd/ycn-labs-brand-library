# Review export scope
The kit's eight PNGs are derived only from the frozen chat upload and are not the canonical `BRAND-EXPORT-05` release.

Included review widths: 128, 256, 384, 512, 768, 1024, 1536, 2048 pixels.
The existing matrix's full-lockup PNG widths are 128, 256, 512, 1024, 2048. Additional widths here are preview/density options, not an unapproved change to that matrix.

Canonical row disposition for the future task:
- Full-lockup/on-dark/PNG: eligible from the verified appropriate approved source, after the approval/review gates.
- Full-lockup/on-light/PNG: pending 02b and 04, or an explicitly approved dark-tile treatment. Never manufacture a light master with a colour filter.
- Mark-only, favicon and app icon: separate candidate and exact-file approval workflow. No approved small mark is supplied here.
- Wordmark-only, social avatar and Open Graph: excluded from this package; separate crop/composition approvals apply.
- SVG, EPS, PDF/X-4, monochrome reductions, animations: excluded. A PDF guide is documentation, not a vector logo export.

The canonical EXPORT_MATRIX.csv was NOT changed. Its `release_gate` values must be updated to actual Owner rulings only during a separately reviewed task.
