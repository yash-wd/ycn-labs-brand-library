# YCN Labs usage rules — proposed operating standard
Use a released file by exact path from the approved release manifest. Never ask a generative model to recreate the logo for a navbar, footer or banner. The receiving design uses the logo asset; it does not draw a lookalike.

Keep the whole approved artwork and its proportions. A different container does not authorize a different logo shape. No stretching, CSS `object-fit: cover`, masks, hue filters, inversion, blend modes, added glow, sharpening, AI upscaling or background removal. For an unapproved white-surface treatment, show a labelled proof only and obtain the Owner's decision.

Use adequate source pixels for the display density. A 128-CSS-pixel placement can use a 256-pixel export at 2x or a 384-pixel export at 3x. This avoids needless upscaling; it does not make fine detail infinitely legible. Never upscale a small export to create a larger one. Always return to the approved master.

Retain existing canvas margins until a trim is approved. Provisional extra clear space and minimum readable size must be demonstrated and approved; this kit does not invent an authoritative numerical rule. A full complex logo and a 16-pixel favicon are different production problems.

For documents and slides, insert the PNG directly, lock its aspect ratio and avoid image recompression when the application allows it. For print, agree output dimensions, effective resolution and colour treatment with the supplier and inspect a proof. A PNG embedded in a PDF or SVG remains raster artwork.

Official references: IBM's 8-Bar usage guide; Microsoft's brand guidelines; MDN responsive-image guidance; Google web.dev responsive-image guidance. Links are in `SOURCES.md`. These references illustrate principles; they do not certify this kit or prescribe YCN's measurements.
