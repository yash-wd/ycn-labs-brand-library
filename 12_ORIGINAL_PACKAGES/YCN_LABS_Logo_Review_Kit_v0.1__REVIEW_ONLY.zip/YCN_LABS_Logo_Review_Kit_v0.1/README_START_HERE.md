# YCN LABS — Logo Review Kit v0.1
**Review edition | 14 October 2026 | Not a production release**

The logo identity is the Owner's final design. This package organises and demonstrates its reuse; it is not a redesign. It is a local review supplement, NOT a clone, replacement or approved release of the canonical brand repository. Do not merge this entire directory into GitHub.

## Open these first
1. `07_GUIDELINES/YCN_LABS_Logo_Control_Manual.pdf` — owner-facing guide.
2. `08_QUALITY_AND_EVIDENCE/REVIEW_GALLERY.html` — offline browser gallery and native-size checks (unzip the complete kit first).
3. `08_QUALITY_AND_EVIDENCE/PNG_EXPORT_PROOF.png` — contact sheet of all eight review exports.
4. `08_QUALITY_AND_EVIDENCE/QA_REPORT.json` — actual local checks.

## What is included
- Your chat-upload PNG, copied byte-for-byte to the dated intake folder.
- Eight review PNGs: widths 128, 256, 384, 512, 768, 1024, 1536 and 2048 pixels. Height follows the source proportions, rounded to a whole pixel. The 2048 file is an unchanged copy; the other seven are direct downscales.
- A draft control manual in Word and PDF; preservation rules; developer/AI handoff; source and output manifests; checksums; a reproducible review-only exporter; a human-vector-artist hiring brief.
- Folder names aligned with the existing 00–14 brand-library structure. Reserved areas are explicitly empty of approved artwork.

## Important source distinction
The attached file is 2048 × 1593, PNG, RGBA, 3,158,378 bytes. Its alpha channel is entirely opaque.
Its locally calculated SHA-256 is:
`86a589fc22a7e09f2df89d8ae0ed043c3bfbb5e6a1009b39b5182dedb95b6633`

The current repository records a different file digest for its archived 2048-pixel reference and identifies a 6675 × 5195 authoritative master. Repository PNG binaries could not be retrieved in this session, so pixel equivalence has NOT been established. A hash difference alone does not prove that the visible artwork changed. This upload never replaces the canonical master.

All exported PNGs here are **CANDIDATE / REVIEW ONLY**. Do not deploy them as an approved production release. Canonical exports must be built by AGY from the locally verified, appropriately approved source after Claude review and Owner authorization.

## What is not included or claimed
No approved transparent master, light variant, favicon, app-icon mark, genuine vector master, print-certified file or website integration is delivered in this review package. No recolouring, background removal, cropping, automatic tracing or image generation was performed. No GitHub commit, push, deployment or CLOSE was performed.

## Canonical authority
Brand repository `main`, read via GitHub: `063e6249d34179491a342fcdc140fd0dd1336624`.
Controlling document: https://github.com/yash-wd/ycn-labs-brand-library/blob/063e6249d34179491a342fcdc140fd0dd1336624/00_GOVERNANCE/CURRENT_SOURCE_AUTHORITY.md
Decision register: https://github.com/yash-wd/ycn-labs-brand-library/blob/063e6249d34179491a342fcdc140fd0dd1336624/14_CONTINUITY/OPEN_OWNER_DECISIONS.md
The repository remains the source of truth. Pending approvals remain pending.
