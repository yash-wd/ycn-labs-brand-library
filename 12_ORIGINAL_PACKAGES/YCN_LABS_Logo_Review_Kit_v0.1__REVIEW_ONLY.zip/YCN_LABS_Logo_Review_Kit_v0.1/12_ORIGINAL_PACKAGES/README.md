# Reserved — existing archives are not duplicated
No historic repository package is bundled or rewritten. Preserve original packages in the canonical library. This review kit is a separate supplement with its own checksum inventory.
