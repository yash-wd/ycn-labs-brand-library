# Review distribution only
`REVIEW_0.1` holds this supplement's inventory and checksums. It is not a signed production release. Do not infer asset approval from successful checksum verification.

A future real release should have an immutable version identifier, exact source/variant approvals, provenance and output hashes, a proof sheet, reviewer acceptance and Owner release/push authorization. Never overwrite a released version in place.
