# No final colour tokens asserted
The logo contains gradients and glow; a handful of sampled RGB values cannot fully describe its artwork. Do not apply a single cyan fill or CSS tint to recreate it.

Document typography and accent colours in this kit are presentation styling, not new approved logo colours or a new corporate typeface decision. Source metadata for this upload does not contain an ICC profile. No colour-profile conversion was performed. A production colour/print specification remains a separate approval and vendor-proof step.
