# Owner decision record — BLANK, NOT APPROVAL
For every artwork approval, record:
- Ruling ID and date/time.
- Exact repository-relative filename.
- Full SHA-256 copied from AGY's actual `sha256sum` output.
- Verdict: APPROVE / REJECT / DEFER.
- Allowed use, theme and restrictions.
- Proof inspected and the Owner's exact approval message.

Current decisions still needed: 02a (dark transparency), 02b (light adaptation), 04 (white-surface treatment), 03 (human vector production). A small-icon crop or simplification requires its own file-specific Owner decision.

Approving the dark master does not approve the light master. Approving either full logo does not approve a mark-only crop. A reviewer PASS is not an artwork approval. A task records the Owner's ruling; it cannot issue one on the Owner's behalf.

Choose the light version or dark-tile treatment only after inspecting the comparison sheet. Website appearance is not substituted for that evidence.
