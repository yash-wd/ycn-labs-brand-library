# Scope and authority — REVIEW ONLY
The Owner reaffirmed the shared artwork as the official final logo and requested professional asset management. That is not permission to invent a different navbar logo, erase detail, approve a light adaptation, auto-trace the image, or publish to GitHub.

This kit provides a local preview of the management system. Its drafts do not override `CURRENT_SOURCE_AUTHORITY.md`, the existing decision register, or the three-seat workflow. GPT has not acted as Claude or AGY.

## State meanings
- AUTHORITATIVE SOURCE: the source already ratified by the Owner in the canonical repository.
- CANDIDATE: newly created or unapproved artwork/export. Not production-ready merely because it has a checksum.
- OWNER-APPROVED VARIANT: the actual file and full SHA-256 named in an explicit Owner ruling.
- RELEASE-READY: approved assets plus completed technical review and release manifest; still no automatic push.
- RELEASED: the approved exact release has been published with Owner authorization.
- SUPERSEDED / ARCHIVED: retained history, never an automatic source for new work.

No logo artwork in this review kit has been newly assigned OWNER-APPROVED VARIANT or RELEASED status.
