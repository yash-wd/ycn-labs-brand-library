#!/usr/bin/env python3
"""Deterministic review-only PNG exports. No network, installs, Git, crops or approvals.
Use an existing Python environment with Pillow. Never modifies the input.
All generated assets are candidates regardless of the source's approval status.
"""
from __future__ import annotations
import argparse
import json
import platform
import re
import shutil
import subprocess
import sys
import zlib
from pathlib import Path
import PIL
from PIL import Image


def sha256(path: Path) -> str:
    # Record the digest emitted by the Linux evidence command.
    result = subprocess.run(['sha256sum', '--', str(path)], check=True,
                            capture_output=True, text=True)
    return result.stdout.split()[0]


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--expect-sha256', required=True, help='Copy from verified sha256sum output.')
    parser.add_argument('--out', type=Path, required=True, help='New or empty review-only directory.')
    parser.add_argument('--widths', default='128,256,384,512,768,1024,1536,2048')
    args = parser.parse_args()
    source = args.source.resolve(strict=True)
    out = args.out.resolve()
    expected = args.expect_sha256.lower()
    if not re.fullmatch(r'[0-9a-f]{64}', expected):
        raise ValueError('Expected SHA-256 must be 64 hexadecimal characters.')
    actual = sha256(source)
    if actual != expected:
        raise ValueError('Source hash mismatch; no export is permitted.')
    if any(p in {'01_IMMUTABLE_SOURCE', '04_APPROVED_LOGO_VARIANTS'} for p in out.parts):
        raise ValueError('Output cannot be in immutable-source or approved-variant directories.')
    if out == source.parent or out in source.parents or out == source:
        raise ValueError('Output directory must be separate from the source directory.')
    if out.exists() and (not out.is_dir() or any(out.iterdir())):
        raise ValueError('Output must be new or empty; existing output is never overwritten.')
    widths = sorted(set(int(v) for v in args.widths.split(',')))
    if not widths or any(v <= 0 for v in widths):
        raise ValueError('Widths must be positive integers.')
    with Image.open(source) as image:
        image.load()
        if image.format != 'PNG' or image.mode not in {'RGB', 'RGBA'}:
            raise ValueError('Expected an RGB/RGBA PNG. No implicit conversion is allowed.')
        if any(w > image.width for w in widths):
            raise ValueError('Upscaling is forbidden. Every target width must fit the source.')
        if image.mode == 'RGBA' and image.getchannel('A').getextrema() != (255, 255):
            raise ValueError('This upload-review recipe is for opaque inputs only.')
        dimensions = [(w, max(1, (w * image.height + image.width // 2) // image.width)) for w in widths]
        if any(h > image.height for _, h in dimensions):
            raise ValueError('Upscaling on either axis is forbidden.')
        out.mkdir(parents=True, exist_ok=True)
        assets = []
        for width, height in dimensions:
            name = f'ycn-labs_full-lockup_opaque_upload-review_{width}x{height}_CANDIDATE.png'
            target = out / name
            if (width, height) == image.size:
                shutil.copy2(source, target)
                operation = 'byte_exact_copy'
            else:
                kwargs = {'compress_level': 9, 'optimize': False}
                if image.info.get('icc_profile'):
                    kwargs['icc_profile'] = image.info['icc_profile']
                image.resize((width, height), resample=Image.Resampling.LANCZOS).save(target, format='PNG', **kwargs)
                operation = 'direct_downscale_LANCZOS'
            with Image.open(target) as check:
                check.load()
                if check.size != (width, height) or check.mode != image.mode:
                    raise RuntimeError(f'Export validation failed for {name}')
            assets.append({'file': name, 'width_px': width, 'height_px': height,
                'sha256': sha256(target), 'bytes': target.stat().st_size,
                'source_file': source.name, 'source_sha256': actual,
                'operation': operation, 'status': 'CANDIDATE_REVIEW_ONLY',
                'crop': None, 'recolour': False, 'background_removed': False,
                'upscaled': False, 'note': 'New output is not a production approval.'})
    if sha256(source) != actual:
        raise RuntimeError('Source changed during export.')
    manifest = {'schema': 'ycn-logo-review-exports/1', 'status': 'NOT_A_PRODUCTION_RELEASE',
        'environment': {'python': platform.python_version(), 'pillow': PIL.__version__, 'zlib': zlib.ZLIB_RUNTIME_VERSION},
        'recipe': {'filter': 'Pillow LANCZOS', 'integer_height_rounding': 'nearest; exact half rounds upward',
                   'png_compress_level': 9, 'png_optimize': False,
                   'colour_conversion': 'none; preserve ICC bytes if present',
                   'limitations': 'Quantized height may differ from the ideal aspect ratio by <= 0.5 px. PNG byte reproducibility requires a matching encoder environment.'},
        'source': {'file': source.name, 'sha256': actual}, 'assets': assets}
    (out/'EXPORT_MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
    (out/'EXPORT_SHA256SUMS.txt').write_text(''.join(f"{a['sha256']}  {a['file']}\n" for a in assets),encoding='utf-8')
    print(json.dumps({'result':'PASS','source_unchanged':True,'exports':len(assets),'status':'REVIEW_ONLY','output':str(out)},indent=2))
    return 0

if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (ValueError, OSError, RuntimeError, subprocess.SubprocessError) as error:
        print(f'HOLD: {error}', file=sys.stderr)
        raise SystemExit(2)
