# Instructions for every designer, developer and AI agent
Use the official YCN Labs release assets. Do not recreate, draw, trace, regenerate, recolour, enhance, crop or replace the mark unless the task explicitly authorizes a separately reviewed candidate.

Before using an asset, resolve its exact filename, SHA-256, approval record, theme and allowed use from the canonical release manifest. No manifest entry means no production substitution. An uploaded screenshot or an old SVG is not automatically an approved source.

Use one shared logo-rendering component in a future separately approved website task. Map usage to approved assets centrally; do not embed different handmade versions in navbar/footer/page sections. Preserve intrinsic aspect ratio, choose density-appropriate files, provide suitable accessible naming, and test actual rendering in each theme. No website file is supplied or changed by this review package.

Do not crop the full lockup into a square or make a new favicon just to satisfy a slot. Stop and request the approved compact mark. An empty asset slot is better than silently publishing a wrong identity.

Integrity hashes protect file identity. They do not prove visual quality or replace Owner approval. A complete release needs both technical verification and visual acceptance.
