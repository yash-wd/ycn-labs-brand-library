# GPT → Claude | Review handoff, not an execution authorization
## Requested verdict
Review this local draft control system and identify PASS/HOLD corrections. It does not claim to complete BRAND-EXPORT-05. Production execution continues to require Owner rulings, Claude review and explicit Owner authorization.

## Current known boundary
Brand main was read at 063e624. The website was neither read nor changed in this work. The local chat upload has been frozen separately. Its checksum differs from the repo-reported archived 2048 reference. Upstream image bytes were not retrievable here; do not assert pixel equality. AGY must resolve this against local canonical files, without overwriting them.

## One next brand execution task: BRAND-EXPORT-05, still blocked on rulings
Scope to carry into the final task once 02a, 02b and 04 are actually supplied:
- Record the Owner's exact decisions, canonical filenames and hashes copied from local sha256sum output. No automatic approvals.
- Preserve 6675 master, archived 2048 reference and transparent candidate source files byte-for-byte. Compare the new upload to the archived reference and report file equality and decoded-pixel equality separately.
- Build only the named eligible full-lockup PNG rows of EXPORT_MATRIX.csv, directly from approved masters, no upscaling or changed artwork. Update release_gate to the actual rulings. Additional density widths are outside the matrix until explicitly authorized.
- Include the authorised brand README correction and a one-line RULING-01 note in FEASIBILITY_AND_BRIEF.md. Do not edit any website documentation.
- Small-icon proposals must remain CANDIDATE and use only explicitly permitted operations. A CANDIDATE label does not authorize generative redrawing or optical simplification. Record any approved proposal operation/crop coordinates and every output hash; never promote it automatically.
- Wordmark-only, social and OG rows stay excluded or separately labelled candidates under explicit scope, not silently included in a production release. No SVG/EPS/PDF-X/animation production.
- Provide one proof sheet of all outputs, including candidates, a provenance manifest, checksums, a reproducible recipe, source before/after hashes, exact command output and exit codes.
- Update only explicitly named brand continuity records and the live brand checksum inventory after all legitimate changes are accounted for. A refreshed checksum list must not conceal an unexpected source change.
- Work in the brand repo only, use explicit git paths, inspect staged content for public-repo safety, commit only as authorized, present evidence and STOP before push. No bulk staging, website work, cleanup/deletions, deploy or CLOSE.

## Subsequent work, not bundled into that task
After the Owner chooses an exact small-icon file and hash, a separate short task records that ruling and exports approved favicon/app-icon sizes. The vector-artist brief is ready as text, but hiring/payment/vector approval is not authorized by drafting it. CLOSE is coordinated once after both working sessions have stopped.
