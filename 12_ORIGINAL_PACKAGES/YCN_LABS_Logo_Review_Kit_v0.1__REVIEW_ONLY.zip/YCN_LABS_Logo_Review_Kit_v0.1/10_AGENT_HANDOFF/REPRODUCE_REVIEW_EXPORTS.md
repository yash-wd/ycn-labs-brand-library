# Rebuild the upload-review PNGs
This is a review demonstration, not authorization to execute BRAND-EXPORT-05 or update a repository.

Prerequisites: Linux `sha256sum` and an existing Python 3 environment with Pillow. No install command is included. From the unzipped review-kit root, use a NEW output directory outside the source folder:

```bash
python 10_AGENT_HANDOFF/build_review_exports.py   --source 11_HISTORICAL_ASSETS/INTAKE/2026-10-14/Main_YCN_LABS_logo_black_8K.png   --expect-sha256 "$(cat 00_GOVERNANCE/UPLOAD_SHA256.txt)"   --out /tmp/ycn-logo-review-rebuild-CHOOSE-A-NEW-DIRECTORY
```

The script refuses mismatched source hashes, upscaling, non-PNG input, replacement of existing output and output paths in immutable/approved folders. Every asset remains CANDIDATE_REVIEW_ONLY. Its opaque-input recipe must not be silently reused for a transparent master.

The source is opened read-only. Each smaller image is resized directly from the source with LANCZOS, with no crop, recolouring, sharpening or alpha removal. The full-size output is copied, not re-encoded. Integer output heights are rounded to the nearest pixel.

Byte-identical rebuilds require the same Pillow/PNG encoder environment; exact versions are recorded in the manifest. A cross-environment encoding difference must be investigated, not disguised as an unchanged file. Pixel comparisons and fresh hashes are required for a new release.
