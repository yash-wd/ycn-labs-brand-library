# Hiring brief — faithful YCN Labs logo reconstruction
## Project
We have a final approved YCN Labs logo design. We need a skilled identity/vector production artist to produce faithful editable master artwork and documented production exports. This is not a rebranding project and not an invitation to design alternatives.

## Source authority
Work from the locked, Owner-ratified 6675 × 5195 PNG in our brand library. Use additional dark/light references only where their exact file versions have been approved. Do not use an uploaded preview as the sole source when the authoritative master is available.

## Required fidelity
Preserve the custom YCN geometry and intentional breaks, LABS letter spacing and colour transitions, luminous crescent, orbital lines, nodes, faint network connections and underline flare. Do not replace the lettering with a similar font, delete delicate features or "improve" the identity. Do not rely on one-click automatic tracing or AI-generated approximations.

## Deliverables
Editable native source (AI or equivalent), a usable SVG with clearly organized layers, and preview PNGs rendered from those delivered files. Also supply a source/asset inventory, font/licensing disclosure if any external resources are used, export settings, and comparison proofs. Describe the artwork truthfully as vector or hybrid. If any glow/effect is raster, provide that ingredient and its resolution limits; do not embed the entire PNG in SVG and call it a vector reconstruction.

## Review milestones
1. Demonstrate difficult features: the Y junction, curved N, crescent edge and a ringed node/flare. Show source-versus-render overlays at matching scale before completing the entire master.
2. Submit the complete layered reconstruction and regional difference/edge comparisons at agreed sizes. Explain unavoidable differences and effects-rendering limitations.
3. Make agreed corrections, deliver clean source files, manifests and hashes, then obtain the Owner's written approval of the exact final versions. Rejected drafts stay archived and clearly unapproved.

## Separate or optional work
A simplified tiny icon, monochrome reduction, light-background redesign, animation and print separations are separately scoped and approved. Do not include them as unreviewed automatic derivatives.

## Please send
Relevant examples of faithful technical-logo reconstruction; a description of your vector/glow approach and software; the proposed milestones, revision allowance, delivery timeframe and quote; and any assumptions or licensing constraints. Please state whether your proposed master will be genuinely vector or a documented hybrid.

Final delivery must be editable and reusable without silently losing the original design. Acceptance is by inspected files, not a promise of mathematically perfect recovery from a flattened image.
